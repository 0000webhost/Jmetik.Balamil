-- Run in Supabase SQL Editor. Keep service-role credentials server-side only.
create extension if not exists pgcrypto;

create table if not exists public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  message text not null,
  status text not null default 'new',
  created_at timestamptz not null default now()
);

create table if not exists public.newsletter_subscribers (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  language text not null default 'es',
  consent_at timestamptz not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  sku text unique,
  slug text not null unique,
  name jsonb not null,
  description jsonb,
  category text,
  price_mxn numeric(12,2) not null check (price_mxn >= 0),
  stock integer not null default 0 check (stock >= 0),
  image_urls text[] not null default '{}',
  active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  provider text not null default 'mercadopago',
  provider_preference_id text,
  provider_payment_id text,
  status text not null default 'pending',
  customer_name text,
  customer_email text,
  customer_phone text,
  shipping_address jsonb,
  shipping_country text,
  shipping_cost_mxn numeric(12,2) default 0,
  currency text not null default 'MXN',
  items jsonb not null,
  total_mxn numeric(12,2) not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- RLS: no public direct reads/writes. Server routes use the service role after validation.
alter table public.contact_messages enable row level security;
alter table public.newsletter_subscribers enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;

-- Product image bucket. Images are public for storefront display; only admins can upload.
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

drop policy if exists "Public can view product images" on storage.objects;
drop policy if exists "Admins can upload product images" on storage.objects;
drop policy if exists "Admins can update product images" on storage.objects;

create policy "Public can view product images"
on storage.objects for select
using (bucket_id = 'product-images');

create policy "Admins can upload product images"
on storage.objects for insert to authenticated
with check (bucket_id = 'product-images' and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

create policy "Admins can update product images"
on storage.objects for update to authenticated
using (bucket_id = 'product-images' and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check (bucket_id = 'product-images' and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
