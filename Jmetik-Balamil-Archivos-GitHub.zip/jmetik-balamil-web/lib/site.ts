export const BRAND = {
  name: 'Jmetik Balamil',
  tagline: 'Raíces que se tejen, historias que trascienden.',
  location: 'San Andrés Larráinzar, Chiapas, México',
  email: 'contacto@jmetikbalamil.mx',
};

export const COLORS = {
  wine: '#8F1A1B', indigo: '#244A68', olive: '#75805A',
  maize: '#D1A33A', ivory: '#E9DDC9', charcoal: '#302B2B',
  clay: '#A66F70', jade: '#397D78', earth: '#79513E',
};

// Sample catalog content for layout testing only. Replace with the cooperative's real SKUs,
// prices, stock, descriptions and approved product photography before enabling live sales.
export const sampleProducts = [
  { id: 'pieza-001', slug: 'textil-artesanal-01', name: 'Pieza textil artesanal', category: 'Textiles', price: 1250, currency: 'MXN', image: 'https://images.unsplash.com/photo-1590736969955-71cc94901144?auto=format&fit=crop&w=1000&q=85', description: 'Fotografía de referencia. Sustituir por la pieza real y su ficha validada.' },
  { id: 'pieza-002', slug: 'accesorio-textil-01', name: 'Accesorio textil', category: 'Accesorios', price: 680, currency: 'MXN', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=85', description: 'Fotografía de referencia. Sustituir por la pieza real y su ficha validada.' },
  { id: 'pieza-003', slug: 'decoracion-textil-01', name: 'Decoración textil', category: 'Hogar', price: 980, currency: 'MXN', image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1000&q=85', description: 'Fotografía de referencia. Sustituir por la pieza real y su ficha validada.' },
];
