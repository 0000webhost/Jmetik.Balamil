'use client';

import { useEffect, useMemo, useState } from 'react';
import { copy, languages, type Lang } from '@/lib/i18n';
import { sampleProducts, BRAND } from '@/lib/site';

type Product = typeof sampleProducts[number];
type CartLine = { product: Product; quantity: number };
type CookiePrefs = { necessary: true; analytics: boolean; marketing: boolean };

const photos = {
  hero: 'https://images.unsplash.com/photo-1604881991720-f91add269bed?auto=format&fit=crop&w=2200&q=90',
  loom: 'https://images.unsplash.com/photo-1452860606245-08befc0ff44b?auto=format&fit=crop&w=1200&q=85',
  hands: 'https://images.unsplash.com/photo-1455390582262-044cdaad277a?auto=format&fit=crop&w=1000&q=85',
  detail: 'https://images.unsplash.com/photo-1605000797499-95a51c5269ae?auto=format&fit=crop&w=1400&q=85',
};

export default function Home() {
  const [lang, setLang] = useState<Lang>('es');
  const [languageOpen, setLanguageOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [checkoutStatus, setCheckoutStatus] = useState('');
  const [cart, setCart] = useState<CartLine[]>([]);
  const [products, setProducts] = useState<Product[]>(sampleProducts);
  const [cookieOpen, setCookieOpen] = useState(false);
  const [cookieSettings, setCookieSettings] = useState(false);
  const [cookiePrefs, setCookiePrefs] = useState<CookiePrefs>({ necessary: true, analytics: false, marketing: false });
  const [currency, setCurrency] = useState('MXN');
  const [rates, setRates] = useState<Record<string, number>>({ MXN: 1 });
  const [formStatus, setFormStatus] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const t = copy[lang];

  useEffect(() => {
    // Ask on each new visit/session. Selection is retained only for this tab session.
    const savedLanguage = sessionStorage.getItem('jb-language') as Lang | null;
    if (savedLanguage && languages.some(item => item.code === savedLanguage)) setLang(savedLanguage);
    setLanguageOpen(!savedLanguage);
    const savedCart = localStorage.getItem('jb-cart');
    if (savedCart) { try { setCart(JSON.parse(savedCart)); } catch { localStorage.removeItem('jb-cart'); } }
    const savedCookies = localStorage.getItem('jb-cookie-preferences');
    if (savedCookies) { try { setCookiePrefs(JSON.parse(savedCookies)); } catch { setCookieOpen(true); } }
    else setCookieOpen(true);
    fetch('https://api.frankfurter.app/latest?from=MXN&to=USD,EUR,CNY')
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(d => setRates({ MXN: 1, ...(d.rates || {}) }))
      .catch(() => setRates({ MXN: 1 }));
  }, []);

  useEffect(() => { localStorage.setItem('jb-cart', JSON.stringify(cart)); }, [cart]);
  useEffect(() => { fetch('/api/products').then(r => r.ok ? r.json() : Promise.reject()).then(d => { if (Array.isArray(d.products) && d.products.length) setProducts(d.products.map((p: any) => ({ id: p.id, slug: p.slug, name: p.name?.[lang] || p.name?.es || 'Pieza artesanal', category: p.category || 'Textiles', price: Number(p.price_mxn), currency: 'MXN', image: p.image_urls?.[0] || '', description: p.description?.[lang] || p.description?.es || '' }))); }).catch(() => {}); }, [lang]);
  const total = useMemo(() => cart.reduce((sum, line) => sum + line.product.price * line.quantity, 0), [cart]);
  const money = (amount: number) => {
    const converted = amount * (rates[currency] || 1);
    return new Intl.NumberFormat(lang === 'zh' ? 'zh-CN' : lang === 'fr' ? 'fr-FR' : lang === 'en' ? 'en-US' : 'es-MX', { style: 'currency', currency }).format(converted);
  };
  const chooseLanguage = (code: Lang) => { setLang(code); sessionStorage.setItem('jb-language', code); setLanguageOpen(false); };
  const addToCart = (product: Product) => setCart(current => {
    const found = current.find(x => x.product.id === product.id);
    return found ? current.map(x => x.product.id === product.id ? { ...x, quantity: x.quantity + 1 } : x) : [...current, { product, quantity: 1 }];
  });
  const updateQuantity = (id: string, quantity: number) => setCart(current => quantity <= 0 ? current.filter(x => x.product.id !== id) : current.map(x => x.product.id === id ? { ...x, quantity } : x));
  const saveCookies = (prefs: CookiePrefs) => { setCookiePrefs(prefs); const value = JSON.stringify(prefs); localStorage.setItem('jb-cookie-preferences', value); document.cookie = `jb_cookie_consent=${encodeURIComponent(value)}; Max-Age=${60*60*24*180}; Path=/; SameSite=Lax`; setCookieOpen(false); setCookieSettings(false); };

  async function submitContact(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setFormStatus('Enviando…');
    const data = Object.fromEntries(new FormData(e.currentTarget).entries());
    try { const res = await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }); if (!res.ok) throw new Error(); setFormStatus(lang === 'es' ? '¡Gracias! Recibimos tu mensaje.' : 'Thank you! Your message has been received.'); e.currentTarget.reset(); }
    catch { setFormStatus(lang === 'es' ? 'No fue posible enviar. Revisa la configuración del servidor.' : 'Could not send. Please check server configuration.'); }
  }
  async function submitNewsletter(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setNewsletterStatus('…'); const form = e.currentTarget; const email = new FormData(form).get('email');
    try { const res = await fetch('/api/newsletter', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, language: lang }) }); if (!res.ok) throw new Error(); setNewsletterStatus(lang === 'es' ? '¡Gracias por suscribirte!' : 'Thanks for subscribing!'); form.reset(); }
    catch { setNewsletterStatus(lang === 'es' ? 'No se pudo completar la suscripción.' : 'Subscription could not be completed.'); }
  }
  async function checkout(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setCheckoutStatus('Procesando…');
    const customer = Object.fromEntries(new FormData(e.currentTarget).entries());
    const res = await fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items: cart.map(x => ({ id: x.product.id, quantity: x.quantity })), customer }) });
    const data = await res.json(); if (data.init_point) window.location.href = data.init_point; else setCheckoutStatus(data.error || 'No fue posible iniciar el pago.');
  }

  return <main>
    <div className="announcement">{t.announcement} <span>✦</span> Envíos nacionales e internacionales</div>
    <header className="header">
      <a href="#inicio" className="brandmark brandmark-icon-only" aria-label="Jmetik Balamil, inicio"><img src="/jmetik-icon.png" alt="" /></a>
      <button className="mobile-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Abrir menú">☰</button>
      <nav className={mobileMenu ? 'nav nav-open' : 'nav'}>
        <a href="#inicio" onClick={() => setMobileMenu(false)}>{t.navHome}</a><a href="#nosotras" onClick={() => setMobileMenu(false)}>{t.navStory}</a><a href="#coleccion" onClick={() => setMobileMenu(false)}>{t.navShop}</a><a href="#proceso" onClick={() => setMobileMenu(false)}>{t.navCraft}</a><a href="#diario" onClick={() => setMobileMenu(false)}>{t.navJournal}</a><a href="#contacto" onClick={() => setMobileMenu(false)}>{t.navContact}</a>
      </nav>
      <div className="header-actions"><button className="language-trigger" onClick={() => setLanguageOpen(true)}>{lang.toUpperCase()}⌄</button><button className="cart-trigger" onClick={() => setCartOpen(true)} aria-label={t.cart}>♧ <span>{cart.reduce((s,x)=>s+x.quantity,0)}</span></button></div>
    </header>

    <section id="inicio" className="hero" style={{ backgroundImage: `linear-gradient(90deg, rgba(25,20,18,.72), rgba(25,20,18,.13)), url(${photos.hero})` }}>
      <div className="hero-copy"><p className="eyebrow light">{t.eyebrow}</p><h1>{t.heroTitle}</h1><p>{t.heroText}</p><div className="hero-buttons"><a className="button button-light" href="#coleccion">{t.explore} <span>↗</span></a><a className="text-link light-link" href="#nosotras">{t.ourStory}</a></div></div>
      <div className="hero-caption">01 / {BRAND.location.toUpperCase()}</div>
    </section>

    <section id="nosotras" className="intro section-pad">
      <div className="intro-image"><img src={photos.loom} alt="Detalle de trabajo textil artesanal"/><span className="image-note">JMETIK BALAMIL · CHIAPAS</span></div>
      <div className="intro-copy"><p className="eyebrow">{t.introLabel}</p><h2>{t.introTitle}</h2><p className="body-large">{t.introText}</p><a className="under-link" href="#mision">{t.ourStory} <span>↗</span></a></div>
    </section>

    <section id="mision" className="purpose section-pad">
      <div className="section-heading"><p className="eyebrow">02 / NUESTRA DIRECCIÓN</p><h2>Una visión compartida</h2></div>
      <div className="purpose-grid"><article><span className="number">01</span><h3>{t.mission}</h3><p>{t.missionText}</p></article><article><span className="number">02</span><h3>{t.vision}</h3><p>{t.visionText}</p></article></div>
      <div className="values"><span>{t.values}</span><p>Identidad <i>·</i> Comunidad <i>·</i> Tradición <i>·</i> Dignidad <i>·</i> Autenticidad <i>·</i> Justicia</p></div>
    </section>

    <section id="coleccion" className="collection section-pad"><div className="section-heading split"><div><p className="eyebrow">03 / PIEZAS CON HISTORIA</p><h2>{t.collection}</h2><p>{t.collectionText}</p></div><a className="under-link" href="#contacto">{t.viewAll} ↗</a></div>
      <div className="product-grid">{products.map((p, i) => <article className="product-card" key={p.id}><div className="product-image"><img src={p.image} alt={p.name}/><span className="product-index">0{i+1}</span></div><div className="product-meta"><div><small>{p.category}</small><h3>{p.name}</h3><p className="price">{money(p.price)}</p></div><button className="add-button" onClick={() => addToCart(p)} aria-label={t.add}>＋</button></div></article>)}</div>
      <p className="demo-note">{t.demo}</p>
    </section>

    <section id="proceso" className="process"><div className="process-image"><img src={photos.detail} alt="Textura artesanal en detalle"/></div><div className="process-copy"><p className="eyebrow light">04 / CONOCIMIENTO QUE PERMANECE</p><h2>{t.process}</h2><p>{t.processText}</p><a className="button button-outline" href="#contacto">{t.ourStory} ↗</a></div></section>

    <section id="diario" className="journal section-pad"><div className="section-heading"><p className="eyebrow">05 / DESDE NUESTRA COMUNIDAD</p><h2>{t.journal}</h2><p>{t.journalText}</p></div><div className="journal-grid"><article><img src={photos.hands} alt="Manos trabajando en un proyecto artesanal"/><small>COMUNIDAD · HISTORIAS</small><h3>El valor de crear en colectivo</h3><a href="#contacto" className="under-link">Leer más ↗</a></article><article><img src={photos.loom} alt="Herramientas y proceso de tejido"/><small>OFICIO · CONOCIMIENTO</small><h3>Un saber que continúa vivo</h3><a href="#contacto" className="under-link">Leer más ↗</a></article></div></section>

    <section id="contacto" className="contact section-pad"><div className="contact-copy"><p className="eyebrow light">06 / ESTAMOS PARA ESCUCHARTE</p><h2>{t.contact}</h2><p>{t.contactText}</p><a href="mailto:contacto@jmetikbalamil.mx" className="contact-email">contacto@jmetikbalamil.mx ↗</a></div><form className="contact-form" onSubmit={submitContact}><label>{t.name}<input required name="name" autoComplete="name"/></label><label>{t.email}<input required type="email" name="email" autoComplete="email"/></label><label>{t.message}<textarea required name="message" rows={4}/></label><button className="button button-light" type="submit">{t.send} ↗</button>{formStatus && <p className="form-status">{formStatus}</p>}</form></section>

    <footer className="footer"><div className="footer-top"><div className="footer-brand"><div className="brandmark brandmark-footer brandmark-icon-only"><img src="/jmetik-icon.png" alt="Símbolo textil de Jmetik Balamil" /></div><p>{t.footerText}</p><div className="socials"><a href="#contacto" aria-label="Instagram">IG</a><a href="#contacto" aria-label="Facebook">FB</a><a href="#contacto" aria-label="TikTok">TK</a><a href="#contacto" aria-label="Pinterest">PI</a></div></div>
      <div className="footer-links"><div><h4>{t.exploreFooter}</h4><a href="#inicio">{t.navHome}</a><a href="#nosotras">{t.navStory}</a><a href="#coleccion">{t.navShop}</a><a href="#proceso">{t.navCraft}</a><a href="#diario">{t.navJournal}</a></div><div><h4>{t.information}</h4><a href="#mision">{t.mission} & {t.vision}</a><a href="/privacidad">{t.privacy}</a><a href="/cookies">{t.cookies}</a><a href="/terminos">{t.terms}</a><a href="/envios">{t.shipping}</a></div><div><h4>{t.help}</h4><a href="#contacto">{t.navContact}</a><a href="/preguntas-frecuentes">{t.faq}</a><a href="/devoluciones">{t.shipping}</a></div></div>
      <div className="newsletter"><h4>{t.newsletter}</h4><p>{t.newsletterText}</p><form onSubmit={submitNewsletter}><input required type="email" name="email" placeholder={t.email}/><button aria-label={t.subscribe}>→</button></form>{newsletterStatus && <small>{newsletterStatus}</small>}</div></div>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} Jmetik Balamil. {t.rights}</span><span>{BRAND.location}</span><div className="footer-utilities"><button onClick={() => setCookieSettings(true)}>{t.cookies} / {t.settings}</button></div></div>
    </footer>

    {languageOpen && <div className="language-sheet-backdrop"><div className="language-modal"><span className="modal-kicker">JMETIK BALAMIL</span><h2>{t.languageTitle}</h2><p>{t.languageText}</p><div className="language-options">{languages.map(l => <button key={l.code} className={lang===l.code?'selected':''} onClick={() => chooseLanguage(l.code)}><span>{l.native}</span><b>{lang===l.code?'✓':'↗'}</b></button>)}</div><small>Español · English · Français · 中文</small></div></div>}

    {cookieOpen && <div className="cookie-banner"><div><strong>{t.cookieTitle}</strong><p>{t.cookieText}</p></div><div className="cookie-actions"><button onClick={() => saveCookies({necessary:true,analytics:false,marketing:false})}>{t.rejectOptional}</button><button onClick={() => saveCookies({necessary:true,analytics:true,marketing:true})}>{t.acceptAll}</button><button className="cookie-settings" onClick={() => setCookieSettings(true)}>{t.settings}</button></div></div>}
    {cookieSettings && <div className="modal-backdrop"><div className="cookie-modal"><button className="modal-close" onClick={() => setCookieSettings(false)}>×</button><p className="eyebrow">JMETIK BALAMIL</p><h2>{t.settings}</h2><p>{t.cookieText}</p><div className="pref-row"><span>{t.necessary}<small>Siempre activas</small></span><input type="checkbox" checked disabled/></div><div className="pref-row"><span>{t.analytics}<small>Nos ayudan a mejorar el sitio</small></span><input type="checkbox" checked={cookiePrefs.analytics} onChange={e=>setCookiePrefs(p=>({...p,analytics:e.target.checked}))}/></div><div className="pref-row"><span>{t.marketing}<small>Permiten medir campañas</small></span><input type="checkbox" checked={cookiePrefs.marketing} onChange={e=>setCookiePrefs(p=>({...p,marketing:e.target.checked}))}/></div><button className="button button-wine full" onClick={() => saveCookies(cookiePrefs)}>{t.save}</button></div></div>}

    {checkoutOpen && <div className="modal-backdrop"><form className="checkout-modal" onSubmit={checkout}><button type="button" className="modal-close" onClick={() => setCheckoutOpen(false)}>×</button><p className="eyebrow">JMETIK BALAMIL · CHECKOUT</p><h2>Datos para tu pedido</h2><div className="checkout-fields"><label>Nombre completo<input name="name" required autoComplete="name"/></label><label>Correo electrónico<input name="email" type="email" required autoComplete="email"/></label><label>Teléfono<input name="phone" required autoComplete="tel"/></label><label>País<input name="country" required defaultValue="México" autoComplete="country-name"/></label><label>Ciudad / Estado<input name="city" required autoComplete="address-level2"/></label><label>Código postal<input name="postal_code" required autoComplete="postal-code"/></label><label className="wide">Dirección completa<input name="address" required autoComplete="street-address"/></label></div><p className="checkout-note">Los envíos internacionales requieren confirmación de tarifa, impuestos y disponibilidad antes de procesar el pedido. El cobro se realizará en MXN.</p><button className="button button-wine full" type="submit">Continuar a Mercado Pago ↗</button>{checkoutStatus && <p className="form-status">{checkoutStatus}</p>}</form></div>}

    {cartOpen && <div className="drawer-backdrop" onClick={() => setCartOpen(false)}><aside className="cart-drawer" onClick={e=>e.stopPropagation()}><div className="drawer-head"><h2>{t.cart}</h2><button onClick={() => setCartOpen(false)}>×</button></div>{cart.length===0 ? <p className="empty-cart">{t.emptyCart}</p> : <><div className="cart-lines">{cart.map(line=><div className="cart-line" key={line.product.id}><img src={line.product.image} alt=""/><div className="cart-line-info"><strong>{line.product.name}</strong><span>{money(line.product.price)}</span><div className="quantity"><button onClick={()=>updateQuantity(line.product.id,line.quantity-1)}>−</button><span>{line.quantity}</span><button onClick={()=>updateQuantity(line.product.id,line.quantity+1)}>＋</button><button className="remove" onClick={()=>updateQuantity(line.product.id,0)}>{t.remove}</button></div></div></div>)}</div><div className="cart-summary"><label>{t.currency}<select value={currency} onChange={e=>setCurrency(e.target.value)}><option value="MXN">MXN</option><option value="USD">USD</option><option value="EUR">EUR</option><option value="CNY">CNY</option></select></label><div><span>{t.subtotal}</span><strong>{money(total)}</strong></div><div><span>{t.total}</span><strong>{money(total)}</strong></div><small>El pago se procesa en MXN. El tipo de cambio mostrado es orientativo y puede variar.</small><button className="button button-wine full" onClick={() => { setCartOpen(false); setCheckoutOpen(true); }}>{t.checkout} ↗</button></div></>}</aside></div>}
  </main>;
}
