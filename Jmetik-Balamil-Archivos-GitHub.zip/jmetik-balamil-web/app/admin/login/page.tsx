'use client';
import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabaseBrowser } from '@/lib/supabase-browser';
export default function AdminLogin() {
  const router = useRouter();
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [error, setError] = useState(''); const [loading, setLoading] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault(); setLoading(true); setError('');
    try {
      const { data, error } = await supabaseBrowser().auth.signInWithPassword({ email, password });
      if (error || !data.user) throw new Error(error?.message || 'No se pudo iniciar sesión.');
      if (data.user.app_metadata?.role !== 'admin') { await supabaseBrowser().auth.signOut(); throw new Error('Esta cuenta no tiene permisos de administración.'); }
      router.push('/admin/productos'); router.refresh();
    } catch (err) { setError(err instanceof Error ? err.message : 'Error al iniciar sesión.'); }
    finally { setLoading(false); }
  }
  return <main className="admin-shell"><a className="admin-back" href="/">← Volver a la tienda</a><section className="admin-card"><p className="eyebrow">JMETIK BALAMIL · ADMINISTRACIÓN</p><h1>Bienvenida de nuevo.</h1><p>Inicia sesión con la cuenta autorizada para gestionar el catálogo de la tienda.</p><form onSubmit={submit} className="admin-form"><label>Correo electrónico<input type="email" autoComplete="username" required value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Contraseña<input type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="button button-wine full" disabled={loading}>{loading?'Validando…':'Iniciar sesión'}</button>{error&&<p className="admin-error">{error}</p>}</form><small>El acceso solo se habilita a usuarios cuyo perfil tenga el rol admin en Supabase.</small></section></main>;
}
