import { NextResponse } from 'next/server';
import { MercadoPagoConfig, Preference } from 'mercadopago';
import { supabaseAdmin } from '@/lib/server';

export async function POST(req: Request) {
  try {
    const token = process.env.MERCADOPAGO_ACCESS_TOKEN;
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
    if (!token || !siteUrl) return NextResponse.json({ error: 'El pago todavía no está configurado. Agrega las credenciales de Mercado Pago.' }, { status: 503 });
    const body = await req.json();
    const requested = Array.isArray(body.items) ? body.items : [];
    const customer = body.customer || {};
    const customerName = String(customer.name || '').trim();
    const customerEmail = String(customer.email || '').trim().toLowerCase();
    const customerPhone = String(customer.phone || '').trim();
    const address = String(customer.address || '').trim();
    const country = String(customer.country || '').trim();
    if (!customerName || !/^\S+@\S+\.\S+$/.test(customerEmail) || !customerPhone || !address || !country) return NextResponse.json({ error: 'Completa tus datos de contacto y envío.' }, { status: 400 });
    if (!requested.length || requested.length > 30) return NextResponse.json({ error: 'Carrito inválido.' }, { status: 400 });
    const db = supabaseAdmin();
    if (!db) return NextResponse.json({ error: 'La tienda todavía no está conectada a la base de datos.' }, { status: 503 });
    const ids = requested.map((line: { id: string }) => String(line.id));
    const { data: catalog, error: catalogError } = await db.from('products').select('id,name,price_mxn,stock,active').in('id', ids);
    if (catalogError) throw catalogError;
    const items = requested.map((line: { id: string; quantity: number }) => {
      const product = catalog?.find(p => p.id === line.id && p.active);
      const quantity = Math.max(1, Math.min(20, Number(line.quantity) || 1));
      if (!product || product.stock < quantity) throw new Error('Una pieza ya no está disponible en la cantidad solicitada. Actualiza tu carrito.');
      return { id: product.id, title: product.name?.es || 'Pieza artesanal', quantity, currency_id: 'MXN', unit_price: Number(product.price_mxn) };
    });
    const client = new MercadoPagoConfig({ accessToken: token });
    const preference = new Preference(client);
    const result = await preference.create({ body: {
      items,
      payer: { name: customerName, email: customerEmail, phone: { number: customerPhone } },
      metadata: { customer_name: customerName, customer_email: customerEmail, customer_phone: customerPhone, shipping_address: address, shipping_city: String(customer.city || ''), shipping_postal_code: String(customer.postal_code || ''), shipping_country: country },
      back_urls: { success: `${siteUrl}/compra/confirmada`, failure: `${siteUrl}/compra/error`, pending: `${siteUrl}/compra/pendiente` },
      auto_return: 'approved', notification_url: `${siteUrl}/api/webhook/mercadopago`,
      statement_descriptor: 'JMETIK BALAMIL',
    }});
    if (result.id) await db.from('orders').insert({ provider: 'mercadopago', provider_preference_id: result.id, status: 'pending', customer_name: customerName, customer_email: customerEmail, customer_phone: customerPhone, shipping_address: { address, city: String(customer.city || ''), postal_code: String(customer.postal_code || ''), country }, shipping_country: country, currency: 'MXN', items, total_mxn: items.reduce((s, x) => s + x.quantity * x.unit_price, 0) });
    return NextResponse.json({ id: result.id, init_point: result.init_point });
  } catch (e) { console.error('checkout route', e); return NextResponse.json({ error: 'No fue posible iniciar el pago.' }, { status: 500 }); }
}
