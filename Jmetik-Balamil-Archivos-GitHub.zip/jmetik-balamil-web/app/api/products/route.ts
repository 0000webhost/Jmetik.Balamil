import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/server';
export async function GET() {
  const db = supabaseAdmin();
  if (!db) return NextResponse.json({ products: [] });
  const { data, error } = await db.from('products').select('id,slug,name,description,category,price_mxn,image_urls,stock').eq('active', true).gt('stock', 0).order('created_at', { ascending: false });
  if (error) return NextResponse.json({ error: 'No fue posible cargar el catálogo.' }, { status: 500 });
  return NextResponse.json({ products: data });
}
