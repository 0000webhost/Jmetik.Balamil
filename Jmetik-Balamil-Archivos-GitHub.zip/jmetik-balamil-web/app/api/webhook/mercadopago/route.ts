import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/server';

// Production note: validate Mercado Pago's x-signature using the webhook secret before
// changing an order to paid. Never trust a browser redirect as proof of payment.
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const db = supabaseAdmin();
  if (!db) return NextResponse.json({ received: true });
  const paymentId = body?.data?.id;
  if (paymentId) {
    // TODO: fetch payment details from Mercado Pago API, validate signature/status/amount,
    // then update the matching order. This is deliberately not marked paid by this stub.
    console.info('Mercado Pago webhook received; payment verification required:', paymentId);
  }
  return NextResponse.json({ received: true });
}
