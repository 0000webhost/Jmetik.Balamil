import { NextResponse } from 'next/server';
import { resendClient, supabaseAdmin } from '@/lib/server';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const name = String(body.name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const message = String(body.message || '').trim();
    if (!name || !/^\S+@\S+\.\S+$/.test(email) || message.length < 5 || message.length > 5000) return NextResponse.json({ error: 'Datos inválidos.' }, { status: 400 });
    const db = supabaseAdmin();
    if (!db) return NextResponse.json({ error: 'Base de datos no configurada.' }, { status: 503 });
    const { error } = await db.from('contact_messages').insert({ name, email, message, status: 'new' });
    if (error) throw error;
    const mail = resendClient();
    if (mail && process.env.CONTACT_TO_EMAIL && process.env.EMAIL_FROM) {
      await mail.emails.send({ from: process.env.EMAIL_FROM, to: process.env.CONTACT_TO_EMAIL, replyTo: email, subject: `Nuevo mensaje web de ${name}`, text: `Nombre: ${name}\nCorreo: ${email}\n\n${message}` });
    }
    return NextResponse.json({ ok: true });
  } catch (e) { console.error('contact route', e); return NextResponse.json({ error: 'No fue posible procesar el mensaje.' }, { status: 500 }); }
}
