import { NextResponse } from 'next/server';
import { resendClient, supabaseAdmin } from '@/lib/server';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const email = String(body.email || '').trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) return NextResponse.json({ error: 'Correo inválido.' }, { status: 400 });
    const db = supabaseAdmin();
    if (!db) return NextResponse.json({ error: 'Base de datos no configurada.' }, { status: 503 });
    const { error } = await db.from('newsletter_subscribers').upsert({ email, language: body.language || 'es', consent_at: new Date().toISOString(), active: true }, { onConflict: 'email' });
    if (error) throw error;
    const mail = resendClient();
    if (mail && process.env.CONTACT_TO_EMAIL && process.env.EMAIL_FROM) await mail.emails.send({ from: process.env.EMAIL_FROM, to: process.env.CONTACT_TO_EMAIL, subject: 'Nueva suscripción a Jmetik Balamil', text: `Nueva suscripción: ${email}` });
    return NextResponse.json({ ok: true });
  } catch (e) { console.error('newsletter route', e); return NextResponse.json({ error: 'No fue posible registrar la suscripción.' }, { status: 500 }); }
}
