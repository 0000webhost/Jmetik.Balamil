import { NextRequest, NextResponse } from 'next/server';
import { isAdminRequest } from '@/lib/admin-auth';
import { supabaseAdmin } from '@/lib/server';

export async function GET(request: NextRequest) {
  if (!(await isAdminRequest(request))) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const db = supabaseAdmin();
  if (!db) return NextResponse.json({ error: 'Falta configurar Supabase' }, { status: 503 });
  const { data, error } = await db.from('products').select('*').order('created_at', { ascending: false });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ products: data });
}

export async function POST(request: NextRequest) {
  if (!(await isAdminRequest(request))) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const db = supabaseAdmin();
  if (!db) return NextResponse.json({ error: 'Falta configurar Supabase' }, { status: 503 });
  const body = await request.json();
  const name = String(body.name || '').trim();
  const description = String(body.description || '').trim();
  const category = String(body.category || '').trim();
  const slug = String(body.slug || '').trim().toLowerCase();
  const price = Number(body.price_mxn);
  const stock = Number(body.stock ?? 0);
  const imageUrl = String(body.image_url || '').trim();
  if (!name || !description || !category || !slug || !Number.isFinite(price) || price < 0 || !Number.isInteger(stock) || stock < 0 || !imageUrl) {
    return NextResponse.json({ error: 'Completa nombre, descripción, categoría, slug, precio, inventario e imagen.' }, { status: 400 });
  }
  const { data, error } = await db.from('products').insert({
    slug, name: { es: name }, description: { es: description }, category,
    price_mxn: price, stock, image_urls: [imageUrl], active: body.active === true,
  }).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ product: data }, { status: 201 });
}

export async function PATCH(request: NextRequest) {
  if (!(await isAdminRequest(request))) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const db = supabaseAdmin();
  if (!db) return NextResponse.json({ error: 'Falta configurar Supabase' }, { status: 503 });
  const body = await request.json();
  if (!body.id) return NextResponse.json({ error: 'Falta el ID del producto.' }, { status: 400 });
  const changes: Record<string, unknown> = { updated_at: new Date().toISOString() };
  if (typeof body.active === 'boolean') changes.active = body.active;
  if (typeof body.name === 'string') changes.name = { es: body.name.trim() };
  if (typeof body.description === 'string') changes.description = { es: body.description.trim() };
  if (typeof body.category === 'string') changes.category = body.category.trim();
  if (typeof body.price_mxn === 'number' && body.price_mxn >= 0) changes.price_mxn = body.price_mxn;
  if (typeof body.stock === 'number' && Number.isInteger(body.stock) && body.stock >= 0) changes.stock = body.stock;
  if (typeof body.image_url === 'string' && body.image_url.trim()) changes.image_urls = [body.image_url.trim()];
  const { data, error } = await db.from('products').update(changes).eq('id', body.id).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ product: data });
}
