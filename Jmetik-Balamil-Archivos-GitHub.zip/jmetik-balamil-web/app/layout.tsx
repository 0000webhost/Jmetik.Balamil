import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://www.jmetikbalamil.mx'),
  title: { default: 'Jmetik Balamil | Raíces que se tejen, historias que trascienden', template: '%s | Jmetik Balamil' },
  description: 'Conoce el trabajo textil de Jmetik Balamil, cooperativa de mujeres tejedoras de San Andrés Larráinzar, Chiapas, México. Explora sus piezas artesanales e historias.',
  applicationName: 'Jmetik Balamil',
  icons: { icon: '/jmetik-icon.png', apple: '/jmetik-icon.png' },
  openGraph: { type: 'website', locale: 'es_MX', siteName: 'Jmetik Balamil', title: 'Jmetik Balamil', description: 'Raíces que se tejen, historias que trascienden.' },
  twitter: { card: 'summary_large_image', title: 'Jmetik Balamil', description: 'Raíces que se tejen, historias que trascienden.' },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body>{children}<div className="global-admin-access"><a href="/admin/login">Iniciar sesión</a></div></body></html>;
}
