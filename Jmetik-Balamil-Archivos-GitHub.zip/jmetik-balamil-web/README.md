# Jmetik Balamil — tienda internacional (starter)

Sitio Next.js App Router con interfaz editorial, selector de idioma (ES/EN/FR/ZH), banner y preferencias de cookies, carrito, selector de moneda de referencia, formularios, newsletter y rutas iniciales para Supabase, Resend y Mercado Pago.

## Identidad de marca aplicada
- Rojo profundo `#8F1A1B`, azul añil `#244A68`, verde oliva `#75805A`.
- Complementarios: `#D1A33A`, `#E9DDC9`, `#302B2B`, `#A66F70`, `#397D78`, `#79513E`.
- Tipografías: Cormorant Garamond y Roboto.
- No se reconstruyó el logotipo. El encabezado usa un marcador tipográfico provisional `JB`; reemplazarlo por el archivo maestro oficial antes de publicar.

## Requisitos
- Node.js 20+
- Proyecto Supabase
- Cuenta Mercado Pago y credenciales de aplicación
- Cuenta Resend y dominio verificado para correo transaccional

## Instalación
```bash
npm install
cp .env.example .env.local
# completar variables de entorno
npm run dev
```

## Base de datos
Ejecutar `supabase/schema.sql` en el SQL Editor de Supabase. Las tablas tienen RLS activado; las rutas de servidor utilizan la service role key, que nunca debe exponerse al navegador.

## Configuración de integraciones
1. Supabase: configurar `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` y `SUPABASE_SERVICE_ROLE_KEY`. Ejecutar `supabase/schema.sql`, que también crea el bucket público de imágenes de productos y sus políticas de carga para administradores.
2. Resend: verificar el dominio remitente, configurar `RESEND_API_KEY`, `EMAIL_FROM` y `CONTACT_TO_EMAIL`.
3. Mercado Pago: configurar `MERCADOPAGO_ACCESS_TOKEN` y `NEXT_PUBLIC_SITE_URL`.
4. Antes de producción, implementar la verificación criptográfica `x-signature` del webhook de Mercado Pago y consultar el pago directamente en la API. El webhook de ejemplo NO marca pedidos como pagados.
5. Configurar costos, reglas y transportistas para envíos nacionales e internacionales. El starter aún no cotiza etiquetas ni tarifas de envío.

## Administración del catálogo
- En el footer existe el enlace discreto **Iniciar sesión**, que abre `/admin/login`.
- Crea los usuarios desde Supabase Authentication (no existe registro público).
- Para dar rol administrador a una cuenta, después de crearla/invitarla, ejecuta en SQL Editor con el correo exacto y autorizado: `update auth.users set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb where email = 'correo@dominio.com';`
- Solo usuarios autenticados con `app_metadata.role = admin` pueden entrar al panel `/admin/productos` y usar las rutas de administración. No compartas la `SUPABASE_SERVICE_ROLE_KEY`.
- El panel permite crear productos, cargar imágenes a Storage, definir descripción, categoría, precio MXN e inventario, editar datos y publicar/despublicar.
- El catálogo público consulta los productos activos de Supabase.

## Estado de esta entrega
Esta entrega es una base de desarrollo (starter), no una tienda lista para producción. El selector de idioma aparece como panel inferior en una nueva sesión cuando no hay idioma elegido; la elección se conserva durante esa sesión. La portada tiene una primera capa de traducción en cuatro idiomas; las páginas legales y el checkout todavía requieren traducción completa y revisión humana. Incluye una portada funcional, selector de idioma, banner y preferencias de cookies, carrito local, formularios, panel de administración protegido, carga de imágenes a Supabase Storage, sincronización del catálogo activo y ruta inicial de preferencia de Mercado Pago. Aún falta completar cotizador de paquetería y verificación de pagos en webhook.

## Pendientes obligatorios antes de vender
- Sustituir las fotos de referencia y los productos/precios de demostración por el catálogo real aprobado por la cooperativa.
- Añadir el logotipo original (SVG/PNG) sin redibujarlo.
- Validar misión, visión y textos institucionales con la cooperativa; el manual los presenta como propuesta editorial.
- Crear páginas legales completas y revisadas para México y mercados de destino (privacidad, cookies, términos, cancelaciones, devoluciones, envíos, impuestos y datos del responsable).
- Completar checkout con datos de cliente/dirección, cálculo de envío, persistencia del pedido y confirmación segura.
- Configurar inventario real y validación de precio/stock desde la base de datos; no confiar en el catálogo de demostración del cliente.
- Añadir controles anti-spam/rate-limit y consentimiento verificable para newsletter.
- Añadir traducciones revisadas por hablantes humanos, especialmente chino y francés, antes de publicar.
- Configurar pruebas, monitoreo, copias de seguridad, dominio, HTTPS y despliegue.

## Nota sobre idioma y cookies
El selector aparece en la parte inferior al comenzar una sesión sin idioma guardado; la elección se conserva durante esa sesión. El aviso de cookies aparece en la parte inferior, con aceptar, rechazar y configurar; la preferencia se conserva en localStorage y en una cookie propia de consentimiento. Las categorías analíticas/marketing no se instalan por defecto; conectar herramientas de medición solo después del consentimiento.

## Moneda
La UI consulta Frankfurter para mostrar una conversión orientativa MXN→USD/EUR/CNY. El checkout se mantiene en MXN; el tipo de cambio no altera el precio cobrado. En producción se debe mostrar fecha/hora de la tasa y manejar indisponibilidad de la API.
