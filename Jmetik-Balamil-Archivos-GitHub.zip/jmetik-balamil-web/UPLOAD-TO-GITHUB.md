# Cómo subir Jmetik Balamil a GitHub (Mac)

## Opción recomendada: GitHub Desktop
1. Descarga y descomprime `jmetik-balamil-web-starter.zip`.
2. En GitHub Desktop inicia sesión y elige **File > Clone Repository**.
3. Clona el repositorio `jmetik-balamil` en tu Mac.
4. Abre la carpeta local del repositorio desde **Repository > Show in Finder**.
5. Copia DENTRO de esa carpeta el contenido de `jmetik-balamil-web` (no copies la carpeta exterior como una carpeta anidada).
6. No copies `.env.local`, `.env`, `node_modules` ni `.next`.
7. En GitHub Desktop revisa los archivos detectados, escribe `Carga inicial Jmetik Balamil` en Summary y pulsa **Commit to main**.
8. Pulsa **Push origin** para enviarlos a GitHub.

## Archivos y extensiones
Conserva las extensiones originales: `.tsx`, `.ts`, `.css`, `.sql`, `.json`, `.md`, `.png` y `.d.ts`. No renombres nada a `.txt`.

## Si GitHub Desktop no detecta los archivos
Comprueba que copiaste los archivos dentro de la carpeta local que contiene `.git`. No subas el ZIP como sustituto del proyecto.

## Seguridad
Nunca publiques secretos ni claves privadas. `.env.example` es una plantilla y sí se puede subir; `.env.local` y `.env` con credenciales no se suben.
